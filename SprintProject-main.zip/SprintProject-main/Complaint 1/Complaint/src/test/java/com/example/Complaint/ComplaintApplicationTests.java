package com.example.Complaint;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ComplaintApplicationTests {

	@Test
	void contextLoads() {
	}

}
