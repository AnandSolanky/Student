package com.example.Advisor;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AdvisorApplicationTests {

	@Test
	void contextLoads() {
	}

}
