package com.example.KnowledgeBase;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KnowledgeBaseApplicationTests {

	@Test
	void contextLoads() {
	}

}
